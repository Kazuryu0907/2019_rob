#include "mbed.h"
void Move(int way,float pwm);
void Move2(int way,float pwm);
void Move_lock(int way,float pwm);
void trans(int a,int dis,float *x,float *y,int *sign);