#include "mbed.h"
void readGyz(double* gz);
void mpu_setup();
void get_offset();
void to_signed(double* all);
void i2c_write(int addr,char regist,char data);
char i2c_read(int addr,char regist);
int i2c_read_16bit(int addr,char registL,char registH);
void offset_adjust(double* all,double* gz);
char *puc(double all);
int rez();
float angle_adjust(float Gein,double all,float Min_ang,float Min_pwm,float Max_pwm_roll);