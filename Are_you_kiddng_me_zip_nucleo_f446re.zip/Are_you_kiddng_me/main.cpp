#include "mbed.h"
#include "rori.h"
#include "Pulse.h"

DigitalIn ins(D12);
DigitalIn intt(D5);
PwmOut outs(D6);
PwmOut outt(D3);
DigitalOut outs_admin(D9);
DigitalOut outt_admin(D4);
RORI roris(PA_0_ALT1,PA_1_ALT1);
//RORI rorit(PA_4_ALT0,PB_0_ALT0);
Serial serial(USBTX,USBRX);
/*
DigitalOut trig(A4);
PulseInOut pl(A5);
*/
DigitalIn disin(D7);
DigitalOut disout(D8);


PulseInOut echo(A5);
PulseInOut trig(D2);



unsigned long int Time_Echo_us=0;
unsigned long int Len_mm_X100=0;
unsigned long int Len_Integer=0;
unsigned long int Len_Fraction=0;


long roris_l = 0;
long rorit_l = 0;
int bunkais = 48;
int bunkait = 1024;
float angs = 0;
float angt = 0;
int counts = 1;
int countt = 1;
bool start_lock = true;
long lasts= 0;
long lastt = 0;
int last_gav = 0;
int gavdis = 0;

DigitalIn inlock_f(D15);
PwmOut lock(D14);

PwmOut sheetwo(D13);//D10 -> D13
DigitalIn stop(D10);
DigitalOut finish_limit(D13);
bool flags = false;
bool flagt = false;
/*
DigitalIn discr1(D14);
DigitalIn discr2(D15);
DigitalOut fieldColor(D13);
DigitalOut cloth(D12);
*/
Timer ts;
Timer tt;
int last_s = 0;
int last_t = 0;

int count_nxdr = 0;
bool boy_next_door = false;
float gavdeviation = 0;
float gavaverage = 0;
float last_gavaverage = 0;
bool flag_two = true;
int main(){
    ins.mode(PullDown);
    intt.mode(PullDown);
    inlock_f.mode(PullDown);
    stop.mode(PullDown);
    ts.start();
    tt.start();
    outs.period_ms(1);
    lock.period_ms(1);
    while(!stop.read())serial.printf("%d\n",stop.read());
    while(1){
        
        
        if(start_lock){
            serial.printf("%s","start");
            serial.printf("%d",inlock_f.read());
            while(!inlock_f.read()){
                lock = 0.9f;
                serial.printf("%s\n","while");
            }
                serial.printf("%s\n","out");
                lock = 0;
                start_lock = false;

            }
        if(ins.read()){
            if(flag_two){
                //sheetwo = 0.3f;
                flag_two = false;
                }
            outs = 0.5f;
            roris.read(&roris_l);
            //serial.printf("%s",":");
            angs = (float)roris_l/bunkais;
            angs *= 360;
            serial.printf("%f\n",angs);
            if(abs(angs) >= 180*counts){
                counts++;
                outs = 0;
                outs_admin = 1;
                wait(1);
                outs_admin = 0;
                }
            
        }else{
            outs = 0;
            //sheetwo = 0;
            }

        if(intt.read()){
            outt = 0.3f;
            serial.printf("%s\n","intt");
            if(tt.read_ms() > 1100){
                outt = 0;
                outt_admin = 1;
                wait(0.5f);
                outt_admin = 0;
                }
        }else{
            outt = 0;
            tt.reset();
            }
        if(disin.read()){
            trig.write_us(1,100);
            Time_Echo_us=echo.read_high_us();
            serial.printf("%s\n","Echo");
            if((Time_Echo_us < 60000) && (Time_Echo_us > 1)) {
                Len_mm_X100 = (Time_Echo_us*34)/2;
                Len_Integer = Len_mm_X100/100;
                gavdis = Len_Integer;
                serial.printf("%d\n",gavdis);
                /*
                gavaverage = 1/(count_nxdr+1)*(count_nxdr*gavaverage+gavdis);//average
                gavdeviation = (count_nxdr*(gavdeviation*gavdeviation+last_gavaverage*last_gavaverage)+gavdis*gavdis)/(count_nxdr+1)-gavaverage*gavaverage;//devication
                last_gavaverage = gavaverage;
                count_nxdr++;
                if(count_nxdr == 5){
                    serial.printf("%s","gavaverage");
                    serial.printf("%s",":");
                    serial.printf("%d\n",gavaverage);
                    count_nxdr = 0;
                    gavaverage = 0;
                    gavdeviation = 0;
                    }
                */
                }
            
            if(abs(gavdis - last_gav) > 250)disout = 1;
            last_gav = gavdis;
            }else{
                disout = 0;
                }
        }
    }
/*
    int Discrimination(bool hoge){
        bool discColor;
        bool discMode;
        discColor=discr1;
        discMode=discr2;
        if(hoge){
            fieldColor=discr1;
            cloth=discr2;
            }else{
                return 0;
                }
                return 1;
        }
*/