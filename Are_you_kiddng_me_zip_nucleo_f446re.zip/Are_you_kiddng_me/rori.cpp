#include "rori.h"
#include "mbed.h"

Serial s(USBTX,USBRX);
RORI::RORI(PinName a,PinName b): pinA(a),pinB(b),DigA(a),DigB(b){
    flag = true;
    DigA.mode(PullDown);
    DigB.mode(PullDown);
    }

void RORI::loli(){
    volatile short hear = DigA.read()<<1 | DigB.read();
    
    s.printf("%d",DigA.read());
    s.printf("%s",":");
    s.printf("%d\n",DigB.read());
    
    if(!dir){
        if(hear == 1){
            dir = hear;
        }else if(hear == 2){
            dir = hear;
        }else if(!hear){
            dir = 0;
        }
    }else if(!hear){
        if(old != dir){
            if(dir == 2){
                enc_count++;
            }else if(dir == 1){
                enc_count--;
            }
        }
        dir = 0;
    }
    old = hear;
    }
    
 void RORI::read(long *a){
    pinA.rise(this,&RORI::loli);
    pinA.fall(this,&RORI::loli);
    pinB.rise(this,&RORI::loli);
    pinB.fall(this,&RORI::loli);
     *a = enc_count;
     }
bool RORI::getflag(){
    return(flag);
    }