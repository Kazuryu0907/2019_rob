#include "mbed.h"

#ifndef RORIRORI
#define RORIRORI
class RORI{
    public:
        RORI(PinName a,PinName b);
        void loli();
        void read(long *a);
        bool getflag();
    private:
        volatile short old;
        volatile short dir;
        volatile long enc_count;
        InterruptIn pinA;
        InterruptIn pinB;
        DigitalIn DigA;
        DigitalIn DigB;
        bool flag;
    };
#endif
/*
float corr(long *one,long *two){
    const float Gein = 0.0001; 
    int def = *one - *two;
    float out;
    if(def > 0)out = def*Gein;
    else if(def < 0)out = -def*Gein;
    return(out);
    }
*/